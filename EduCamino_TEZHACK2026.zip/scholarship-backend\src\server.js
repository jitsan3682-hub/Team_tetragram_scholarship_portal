require('dotenv').config();
const app = require('./app');

const PORT = process.env.PORT || 5000;

app.listen(PORT, '0.0.0.0', () => {
  console.log(`===================================================`);
  console.log(`  EduCamino Backend Server running on port ${PORT}`);
  console.log(`  Health check: http://localhost:${PORT}/api/v1/status`);
  console.log(`===================================================`);
});
